<template>
  <div>
      <Navbar class="nav"></Navbar>
      <div class="main-content">
          User
      </div>
      <Footer></Footer>
  </div>
</template>
<script>
import Footer from '../Footer'
import Navbar from '../Navbar'

export default {
    components:{
        Footer,
        Navbar
    }
  
}
</script>
<style scoped>

</style>
