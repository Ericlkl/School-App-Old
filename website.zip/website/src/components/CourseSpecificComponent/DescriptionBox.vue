<template>
<div class="box" style="">
    <article class="media">
        <div class="media-content">
                <div class="content">
                <h4 class="has-text-centered title is-4"> <u>Course Description </u></h4>
                <br>
                <p>
                    The course will intoduce you to the basics of violin, you will learn from the best teachers in the industry that perform on world stages around the globe
                </p>
            </div>
        </div>
    </article>
</div>

</template>
<script>

export default {
  
}
</script>
<style scoped>

</style>
