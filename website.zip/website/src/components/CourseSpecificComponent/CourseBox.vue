<template>
<div class="box" style="background-color:grey; ">
    <article class="media fix">
        <div class="media-content fix" >
                <div class="content has-text-centered ">
                <h4 class="title is-4 coursetitle">Course Name</h4>
                <br>
                <img class="image" src="https://tw.yamaha.com/zh/files/yvn500s_540x540_396x396_81537326aeac9ea1a2738b7054f25f37.jpg" alt="">
                <br>
                <table class="table is-hoverable">
                    <tr>
                    <td>Course Name :Basics for violin</td>
                    </tr>
                    <tr>
                    <td>Instrument  : Violin</td>
                    </tr>
                    <tr>
                    <td>Teacher Name : Jack Sparrow</td>
                    </tr>
                </table>
            </div>
        </div>
    </article>
</div>

</template>
<script>

export default {
  
}
</script>
<style scoped>
h4{
    color:#363636 !important ;
}
.box{
    
    background-color:white !important;
}
.coursetitle{
    color:white;
}

</style>
