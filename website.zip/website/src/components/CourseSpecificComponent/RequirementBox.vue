<template>
<div class="box" style="">
    <article class="media">
        <div class="media-content">
                <div class="content">
                <h4 class="has-text-centered title is-4">Enrol Requirement</h4>
                <br>
                <p>
                    The instrument will be provided, just come to class
                </p>
            </div>
        </div>
    </article>
</div>

</template>
<script>

export default {
  
}
</script>
<style scoped>

</style>
