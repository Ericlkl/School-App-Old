<template>
<div class="box" style="">
    <article class="media">
        <div class="media-content">
                <div class="content">
                <h4 class="has-text-centered title is-4">Tution Fee</h4>
                <br>
                <p>
                   $ 2000 per year
                </p>
            </div>
        </div>
    </article>
</div>

</template>
<script>

export default {
  
}
</script>
<style scoped>

</style>
